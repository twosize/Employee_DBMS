from flask import Flask, render_template, request, flash,redirect, url_for
import sqlite3

app = Flask(__name__)
app.secret_key = 'some_secret_key'
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/redirect_to_home')
def redirect_to_home():
    return redirect(url_for('home'))

@app.route('/searchEmployee', methods=['POST'])
def search():
    query = request.form['query']
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM employee WHERE Fname LIKE ? OR ssn LIKE ?", ('%'+query+'%', '%'+query+'%'))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    if len(rows) > 0:
        flash(f"{len(rows)} Employee found for query '{query}'")
    else:
        flash(f"No Employee found for query '{query}'")
    return render_template('searchEmployee.html', rows=rows)

@app.route('/searchDependent', methods=['POST'])
def searchDependent():
    query = request.form['query']
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM Dependent WHERE EmployeeSSN LIKE ? OR DependentName LIKE ?", ('%'+query+'%', '%'+query+'%'))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    if len(rows) > 0:
        flash(f"{len(rows)} dependents found for query '{query}'")
    else:
        flash(f"No dependents found for query '{query}'")
    return render_template('searchDependent.html', rows=rows)



@app.route('/insertEmployee', methods=['POST'])
def insert():
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cursor = conn.cursor()
    query = "INSERT INTO Employee (SSN, DOB, Fname, Minit, Lname, Address) VALUES (?, ?, ?, ?, ?, ?)"
    cursor.execute("SELECT SSN FROM Employee")
    existing_ssns = [str(row[0]) for row in cursor.fetchall()]
    ssn = request.form.get('ssn')
    dob = request.form.get('dob')
    fname = request.form.get('fname')
    minit = request.form.get('minit')
    lname = request.form.get('lname')
    address = request.form.get('address')
    if ssn in existing_ssns:
        return f"SSN {ssn} already exists in the database"
    if not ssn.isdigit() or not len(ssn) == 9:
        return "SSN must be number and 9 digits"

    cursor.execute(query, (ssn, dob, fname, minit, lname, address))
   
    select_employee_query = "SELECT * FROM Employee"
    cursor.execute(select_employee_query)
    employees = cursor.fetchall()
    flash(f"Employee {ssn}, {dob}, {fname}, {minit}, {lname}, {address} Successfuly Inserted.")
    conn.commit()
    conn.close()
    return render_template('insertEmployee.html', employees=employees)

@app.route('/insertDependent', methods=['POST'])
def insertDependent():
    dependent_name = request.form['dependent_name']
    relationship = request.form['relationship']
    employee_ssn = request.form['employee_ssn']

    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cur = conn.cursor()
    cur.execute("""
    INSERT INTO Dependent (DependentName, Relationship, EmployeeSSN)
    SELECT ?, ?, ?
    WHERE EXISTS (SELECT 1 FROM Employee WHERE SSN = ?)
    """, (dependent_name, relationship, employee_ssn, employee_ssn))
    if cur.rowcount == 0:
        flash(f"Error: No SSN in Employee table matching.")
    else:
        flash(f"dependent '{dependent_name}' '{relationship}' '{relationship}' successfully inserted.")
    
    select_dependent_query = "SELECT * FROM Dependent"
    cur.execute(select_dependent_query)
    dependents = cur.fetchall()
    
    select_employee_query = "SELECT * FROM Employee"
    cur.execute(select_employee_query)
    employees = cur.fetchall()
    
   
    conn.commit()
    cur.close()
    conn.close()

    return render_template('insertdependent.html', dependents=dependents,employees=employees)


@app.route('/deleteEmployee', methods=['POST'])
def delete():
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cursor = conn.cursor()
    
    ssn = request.form.get('ssn')
    
    
    query = "DELETE FROM Employee WHERE SSN = ? "
    cursor.execute(query, (ssn,))
    if cursor.rowcount == 0:
        flash(f"Error: SSN '{ssn}' not found in the table.")
    else:
        flash(f"employee with SSN '{ssn}' successfully deleted.")
    

    query = "DELETE FROM Dependent WHERE EmployeeSSN = ? "
    cursor.execute(query, (ssn,))
    if cursor.rowcount >0:
        num_deleted = cursor.rowcount
        flash(f"{num_deleted} dependent(s) for employee with SSN '{ssn}' successfully deleted.")
    
  
    select_employee_query = "SELECT * FROM Employee"
    cursor.execute(select_employee_query)
    employees = cursor.fetchall()
    
    select_dependent_query = "SELECT * FROM Dependent"
    cursor.execute(select_dependent_query)
    dependents = cursor.fetchall()
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return render_template('deleteEmployee.html', employees=employees, dependents=dependents)

@app.route('/deleteDependent', methods=['POST'])
def deleteDependent():
    dependent_name = request.form['dependent_name']
    employee_ssn = request.form['employee_ssn']

    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cur = conn.cursor()
    cur.execute("DELETE FROM Dependent WHERE DependentName=? AND EmployeeSSN=?", (dependent_name, employee_ssn))

    if cur.rowcount == 0:
        flash(f"Error: Dependent '{dependent_name}' for employee with SSN '{employee_ssn}' not found in the table.")
    else:
        flash(f"Dependent '{dependent_name}' for employee with SSN '{employee_ssn}' successfully deleted.")

   
    select_dependent_query = "SELECT * FROM Dependent"
    cur.execute(select_dependent_query)
    dependents = cur.fetchall()

    conn.commit()
    cur.close()
    conn.close()

    return render_template('deleteDependent.html', dependents=dependents)

@app.route('/update', methods=['POST'])
def update():
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cursor = conn.cursor()
    old_ssn = request.form.get('old_ssn')
    new_ssn = request.form.get('new_ssn')
    fname = request.form.get('fname')
    minit = request.form.get('minit')
    lname = request.form.get('lname')
    address = request.form.get('address')
 
    select_query = "SELECT * FROM Employee WHERE SSN = ?"
    cursor.execute(select_query, (old_ssn,))
    employee = cursor.fetchone()
    if not employee:
        return f"Employee with SSN {old_ssn} does not exist"
    
    update_query = "UPDATE Employee SET SSN = ?, Fname = ?, Minit = ?, Lname = ?, Address = ? WHERE SSN = ?"
    cursor.execute(update_query, (new_ssn, fname, minit, lname, address, old_ssn))

    update_dependent_query = "UPDATE Dependent SET EmployeeSSN = ? WHERE EmployeeSSN = ?"
    cursor.execute(update_dependent_query, (new_ssn, old_ssn))

    conn.commit()
    conn.close()
    
    return f"Employee with SSN {old_ssn} updated successfully"

@app.route('/updateDependent', methods=['POST'])
def updateDependent():
    dependent_name = request.form.get('dependent_name')
    relationship = request.form.get('relationship')
    employee_ssn = request.form.get('employee_ssn')
    old_dependent_name = request.form.get('old_dependent_name')

    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cursor = conn.cursor()

    select_query = "SELECT * FROM Dependent WHERE DependentName = ? AND EmployeeSSN = ?"
    cursor.execute(select_query, (old_dependent_name, employee_ssn))
    dependent = cursor.fetchone()

    if not dependent:
        return f"Dependent with name {old_dependent_name} and employee SSN {employee_ssn} does not exist"

    update_query = "UPDATE Dependent SET DependentName = ?, Relationship = ? WHERE DependentName = ? AND EmployeeSSN = ?"
    cursor.execute(update_query, (dependent_name, relationship, old_dependent_name, employee_ssn))
    conn.commit()
    conn.close()

    return f"Dependent with name {old_dependent_name} and employee SSN {employee_ssn} updated successfully"

@app.route('/view')
def view():
    conn = sqlite3.connect('/Users/brandontiong/Documents/Mysql/employeeTest.db')
    cursor = conn.cursor()
    
    table_names = ["Employee", "Dependent", "SalariedEmp", "HourlyEmp", "Department", "Works", "DeptLocation", "Project", "Manages"]
    
    tables = {}
    for table_name in table_names:
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        cursor.execute(f"SELECT * FROM {table_name}")
        rows = cursor.fetchall()
        
        tables[table_name] = {"column_names": column_names, "rows": rows}
    
    conn.close()
    
    return render_template('view.html', tables=tables)


if __name__ == '__main__':
     app.run()
